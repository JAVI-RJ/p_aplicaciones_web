package com.delivery.repository;

import com.delivery.model.Carrito;
import com.delivery.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CarritoRepository extends JpaRepository<Carrito, Long> {
    Optional<Carrito> findByUsuarioAndActivo(Usuario usuario, boolean activo);
}