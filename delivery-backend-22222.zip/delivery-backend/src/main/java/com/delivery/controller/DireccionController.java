package com.delivery.controller;

import com.delivery.model.Direccion;
import com.delivery.model.Usuario;
import com.delivery.service.DireccionService;
import com.delivery.service.UsuarioService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/direcciones")
public class DireccionController {
    @Autowired
    private DireccionService direccionService;

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<Direccion> crearDireccion(@Valid @RequestBody DireccionRequest direccionRequest, Authentication authentication) {
        Usuario usuario = usuarioService.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        Direccion direccion = new Direccion();
        direccion.setUsuario(usuario);
        direccion.setCalle(direccionRequest.getCalle());
        direccion.setCiudad(direccionRequest.getCiudad());
        direccion.setCodigoPostal(direccionRequest.getCodigoPostal());
        direccion.setPais(direccionRequest.getPais());
        return ResponseEntity.ok(direccionService.save(direccion));
    }

    @GetMapping
    public ResponseEntity<List<Direccion>> getDirecciones(Authentication authentication) {
        Usuario usuario = usuarioService.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        List<Direccion> direcciones = direccionService.getDireccionesByUsuario(usuario);
        return ResponseEntity.ok(direcciones);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDireccion(@PathVariable Long id, Authentication authentication) {
        Usuario usuario = usuarioService.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        Direccion direccion = direccionService.findByIdAndUsuario(id, usuario)
                .orElseThrow(() -> new RuntimeException("Dirección no encontrada o no autorizada"));
        direccionService.deleteById(id);
        return ResponseEntity.ok().build();
    }
}

class DireccionRequest {
    @NotNull(message = "La calle es obligatoria")
    private String calle;

    @NotNull(message = "La ciudad es obligatoria")
    private String ciudad;

    @NotNull(message = "El código postal es obligatorio")
    private String codigoPostal;

    @NotNull(message = "El país es obligatorio")
    private String pais;

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }
}