package com.delivery.controller;

import com.delivery.model.Carrito;
import com.delivery.model.CarritoProducto;
import com.delivery.model.Producto;
import com.delivery.model.Usuario;
import com.delivery.service.CarritoService;
import com.delivery.service.ProductoService;
import com.delivery.service.UsuarioService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/carrito")
public class CarritoController {
    @Autowired
    private CarritoService carritoService;

    @Autowired
    private ProductoService productoService;

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping
    public ResponseEntity<Carrito> getCarrito(Authentication authentication) {
        Usuario usuario = usuarioService.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        Carrito carrito = carritoService.getCarritoActivo(usuario);
        return ResponseEntity.ok(carrito);
    }

    @PostMapping("/agregar")
    public ResponseEntity<CarritoProducto> agregarProducto(
            @Valid @RequestBody AgregarProductoRequest request,
            Authentication authentication) {
        Usuario usuario = usuarioService.findByEmail(authentication.getName())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        Producto producto = productoService.getProductoById(request.getProductoId())
                .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        Carrito carrito = carritoService.getCarritoActivo(usuario);
        CarritoProducto carritoProducto = carritoService.agregarProducto(carrito, producto, request.getCantidad());
        return ResponseEntity.ok(carritoProducto);
    }
}

class AgregarProductoRequest {
    @NotNull(message = "El ID del producto es obligatorio")
    private Long productoId;

    @NotNull(message = "La cantidad es obligatoria")
    @Positive(message = "La cantidad debe ser mayor que 0")
    private Integer cantidad;

    public Long getProductoId() {
        return productoId;
    }

    public void setProductoId(Long productoId) {
        this.productoId = productoId;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}