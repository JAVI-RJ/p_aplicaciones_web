package com.delivery.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {
    @GetMapping("/")
    public String root() {
        return "Welcome to Delivery Backend! Use /api/auth/login or /api/auth/register for authentication.";
    }
}