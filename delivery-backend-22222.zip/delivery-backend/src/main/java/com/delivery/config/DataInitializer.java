package com.delivery.config;

import com.delivery.model.Usuario;
import com.delivery.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    private final UsuarioRepository usuarioRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public DataInitializer(UsuarioRepository usuarioRepository, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        if (usuarioRepository.findByEmail("admin@torowings.com").isEmpty()) {
            Usuario admin = new Usuario();
            admin.setNombre("Admin");
            admin.setApellido("User");
            admin.setEmail("admin@torowings.com");
            String passwordHash = passwordEncoder.encode("admin123");
            admin.setPassword(passwordHash);
            admin.setRol("ADMIN");
            usuarioRepository.save(admin);
            System.out.println("Admin user created: admin@torowings.com with password hash: " + passwordHash);
        } else {
            System.out.println("Admin user already exists: admin@torowings.com");
        }
    }
}