package com.delivery.service;

import com.delivery.model.Carrito;
import com.delivery.model.CarritoProducto;
import com.delivery.model.Producto;
import com.delivery.model.Usuario;
import com.delivery.repository.CarritoRepository;
import com.delivery.repository.CarritoProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CarritoService {
    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private CarritoProductoRepository carritoProductoRepository;

    public Carrito getCarritoActivo(Usuario usuario) {
        return carritoRepository.findByUsuarioAndActivo(usuario, true)
                .orElseGet(() -> {
                    Carrito carrito = new Carrito();
                    carrito.setUsuario(usuario);
                    carrito.setCarritoProductos(new ArrayList<>());
                    return carritoRepository.save(carrito);
                });
    }

    public CarritoProducto agregarProducto(Carrito carrito, Producto producto, Integer cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que 0");
        }
        CarritoProducto carritoProducto = carrito.getCarritoProductos().stream()
                .filter(cp -> cp.getProducto().getId().equals(producto.getId()))
                .findFirst()
                .orElse(null);
        if (carritoProducto == null) {
            carritoProducto = new CarritoProducto();
            carritoProducto.setCarrito(carrito);
            carritoProducto.setProducto(producto);
            carritoProducto.setCantidad(cantidad);
            carritoProducto = carritoProductoRepository.save(carritoProducto);
            carrito.getCarritoProductos().add(carritoProducto);
        } else {
            carritoProducto.setCantidad(carritoProducto.getCantidad() + cantidad);
            carritoProducto = carritoProductoRepository.save(carritoProducto);
        }
        carritoRepository.save(carrito);
        return carritoProducto;
    }

    public Carrito save(Carrito carrito) {
        return carritoRepository.save(carrito);
    }
}