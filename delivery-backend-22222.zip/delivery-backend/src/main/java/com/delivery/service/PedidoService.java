package com.delivery.service;

import com.delivery.model.Carrito;
import com.delivery.model.CarritoProducto;
import com.delivery.model.Pedido;
import com.delivery.model.DetallePedido;
import com.delivery.model.Direccion;
import com.delivery.model.Usuario;
import com.delivery.repository.PedidoRepository;
import com.delivery.repository.DetallePedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PedidoService {
    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private DetallePedidoRepository detallePedidoRepository;

    @Autowired
    private CarritoService carritoService;

    @Autowired
    private DireccionService direccionService;

    public Pedido crearPedido(Usuario usuario, Long direccionId) {
        Carrito carrito = carritoService.getCarritoActivo(usuario);
        List<CarritoProducto> items = carrito.getCarritoProductos();

        if (items.isEmpty()) {
            throw new RuntimeException("El carrito está vacío");
        }

        Direccion direccion = direccionService.findByIdAndUsuario(direccionId, usuario)
                .orElseThrow(() -> new RuntimeException("Dirección no encontrada o no autorizada"));

        Pedido pedido = new Pedido();
        pedido.setUsuario(usuario);
        pedido.setDireccion(direccion);
        pedido.setFecha(LocalDateTime.now());
        pedido.setEstado("PENDIENTE");
        double total = items.stream()
                .mapToDouble(item -> item.getProducto().getPrecio() * item.getCantidad())
                .sum();
        pedido.setTotal(total);

        pedido = pedidoRepository.save(pedido);

        for (CarritoProducto item : items) {
            DetallePedido detalle = new DetallePedido();
            detalle.setPedido(pedido);
            detalle.setProducto(item.getProducto());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(item.getProducto().getPrecio());
            detallePedidoRepository.save(detalle);
        }

        carrito.setActivo(false);
        carritoService.save(carrito);

        return pedido;
    }

    public List<Pedido> getPedidosByUsuario(Usuario usuario) {
        return pedidoRepository.findByUsuario(usuario);
    }

    public Optional<Pedido> findByIdAndUsuario(Long id, Usuario usuario) {
        return pedidoRepository.findById(id)
                .filter(pedido -> pedido.getUsuario().getId().equals(usuario.getId()));
    }
}