package com.delivery.service;

import com.delivery.model.Direccion;
import com.delivery.model.Usuario;
import com.delivery.repository.DireccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DireccionService {
    @Autowired
    private DireccionRepository direccionRepository;

    public Direccion save(Direccion direccion) {
        return direccionRepository.save(direccion);
    }

    public List<Direccion> getDireccionesByUsuario(Usuario usuario) {
        return direccionRepository.findByUsuario(usuario);
    }

    public Optional<Direccion> findByIdAndUsuario(Long id, Usuario usuario) {
        return direccionRepository.findById(id)
                .filter(d -> d.getUsuario().getId().equals(usuario.getId()));
    }

    public void deleteById(Long id) {
        direccionRepository.deleteById(id);
    }
}